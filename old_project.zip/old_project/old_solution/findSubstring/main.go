package main

func findSubstring(s string, words []string) []int {
	return []int{}
}

func main() {

}
