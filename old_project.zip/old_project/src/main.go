package main

func main() {

	//testIsValidSudoku036()

	//testSolveSudoku37()

	//testUniquePaths62()

	//testIsSymmetric101()

	//testSortedListToBST109()

	//testIsBalanced110()

	//testFlatten114()

	//testNumDistinct115()

	//testGeneratePascalTriangle118()

	//testTriangle120()

	//testMaxProfit121_123()

	//testIsPalindrome125()

	//testSumNumbers129()

	//testReorderList143()

	//testInsertionSortList147()

	//testSortList148()

	//testFindMin153()

	testFindPeakElement162()

	//testTrailingZeroes172()
}
